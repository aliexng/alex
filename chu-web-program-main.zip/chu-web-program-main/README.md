-虛擬環境安裝-  

1->環境變數  
C:\Users\C4\AppData\Local\Programs\Python\Python312\Scripts  
C:\Users\C4\AppData\Local\Programs\Python\Python312  
  
2->安裝virtualenv  
pip install virtualenv  
virtualenv 取一個名稱  
  
3->啟動  
到虛擬環境Scripts目錄中啟動  
activate  

-相關-  
virtualenv->virtualenv -p python3.10 XXX  
flask->https://flask.palletsprojects.com/en/3.0.x/  
sqlitebrowser->https://sqlitebrowser.org/dl/  
line_develop->https://developers.line.biz/zh-hant/  
ngrok->https://ngrok.com/  
氣象資料開放平臺->https://opendata.cwa.gov.tw/index  
https://opendata.cwa.gov.tw/api/v1/rest/datastore/F-C0032-001?Authorization=(API_Key)&format=JSON  

![image](https://github.com/miyachun/chu-web-program/blob/main/demo.png)
